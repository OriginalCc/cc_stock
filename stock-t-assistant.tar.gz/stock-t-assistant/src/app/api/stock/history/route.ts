import { NextRequest, NextResponse } from "next/server";
import { getStockHistory } from "@/lib/finance-api";
import { calculateMACD, generateMACDSignals, calculateSMA, calculateKDJ, type MACDData } from "@/lib/indicators";

export async function GET(request: NextRequest) {
  const symbol = request.nextUrl.searchParams.get("symbol");
  const interval = request.nextUrl.searchParams.get("interval") || "5m";
  const limit = parseInt(request.nextUrl.searchParams.get("limit") || "200", 10);

  if (!symbol) {
    return NextResponse.json({ error: "缺少股票代码" }, { status: 400 });
  }

  try {
    const history = await getStockHistory(symbol, interval, limit);

    if (history.length === 0) {
      return NextResponse.json({
        symbol,
        interval,
        data: [],
        macd: [],
        signals: [],
      });
    }

    // Calculate MACD
    const closePrices = history.map((h) => h.close);
    const macdData = calculateMACD(closePrices);
    const signals = generateMACDSignals(macdData);

    // Calculate moving averages
    const ma5 = calculateSMA(closePrices, 5);
    const ma10 = calculateSMA(closePrices, 10);
    const ma20 = calculateSMA(closePrices, 20);

    // Calculate KDJ
    const highs = history.map((h) => h.high);
    const lows = history.map((h) => h.low);
    const kdjData = calculateKDJ(highs, lows, closePrices);

    // Combine data
    const combinedData = history.map((item, i) => ({
      ...item,
      ma5: isNaN(ma5[i]) ? null : Number(ma5[i].toFixed(2)),
      ma10: isNaN(ma10[i]) ? null : Number(ma10[i].toFixed(2)),
      ma20: isNaN(ma20[i]) ? null : Number(ma20[i].toFixed(2)),
      dif: isNaN(macdData[i].dif) ? null : macdData[i].dif,
      dea: isNaN(macdData[i].dea) ? null : macdData[i].dea,
      macd: isNaN(macdData[i].macd) ? null : macdData[i].macd,
      k: isNaN(kdjData[i].k) ? null : kdjData[i].k,
      d: isNaN(kdjData[i].d) ? null : kdjData[i].d,
      j: isNaN(kdjData[i].j) ? null : kdjData[i].j,
      signal: signals[i],
    }));

    // Find latest signal
    const latestSignal = signals.filter((s) => s.type !== "hold").pop() || signals[signals.length - 1];

    return NextResponse.json({
      symbol,
      interval,
      count: combinedData.length,
      data: combinedData,
      latestSignal,
    });
  } catch (error: any) {
    console.error("History API error:", error);
    return NextResponse.json(
      { error: "获取历史数据失败" },
      { status: 500 }
    );
  }
}
